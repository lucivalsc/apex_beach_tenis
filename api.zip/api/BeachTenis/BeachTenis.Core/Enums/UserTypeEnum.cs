﻿namespace BeachTenis.Core.Enums
{
    public enum UserTypeEnum
    {
        Teacher = 1,
        Student = 2,
        Professional = 3,
        Athlete = 4,
    }
}
