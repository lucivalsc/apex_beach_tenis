﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeachTenis.Core.Enums
{
    public enum StatusEnum
    {
        Ativado = 1,
        Desativado = 2,
    }
}
