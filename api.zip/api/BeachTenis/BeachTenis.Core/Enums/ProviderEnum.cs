﻿namespace BeachTenis.Core.Enums
{
    public enum ProviderEnum
    {
        Google = 1,
        Facebook = 2,
    }
}
