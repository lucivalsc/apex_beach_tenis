﻿namespace BeachTenis.Core.Entidades
{
    internal class Game
    {
    }
}
