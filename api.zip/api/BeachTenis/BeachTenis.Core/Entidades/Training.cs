﻿namespace BeachTenis.Core.Entidades
{
    internal class Training
    {
    }
}
